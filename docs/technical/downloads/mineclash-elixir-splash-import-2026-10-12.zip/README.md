# MineClash 圣水死亡动画最小导入包

Minecraft 1.21.1 / NeoForge / Java 21。只含可复制源码，无 JAR、PNG 动画或第三方素材。

1. 将 src/main/ 合并进 MineClash 工程；保留 dev.mineclash.elixirsplash 包路径。
2. MineClash 主入口构造器添加：

```java
container.registerConfig(net.neoforged.fml.config.ModConfig.Type.CLIENT,
    dev.mineclash.elixirsplash.SplashConfig.SPEC, "mineclash-elixir-splash-client.toml");
```

3. 在 MineClash META-INF/neoforge.mods.toml 追加：

```toml
[[mixins]]
config="elixirsplash.mixins.json"
```

4. MineClashElixirClient 已按 modid=mineclash 注册客户端 tick/render，无需再手工重复注册。
5. 编译 MineClash 后测试原生死亡结束事件 60。不要给既有死亡链重复发包，也不要把客户端 Mixin 移入服务端通用列表。

完整导入、参数、限制和实机证据：
https://github.com/bendy17323333-lang/royale-spells-fabric/blob/main/docs/technical/19-mineclash-elixir-death-vfx.md

MIT 适用自编代码。MineClash / Minecraft / Supercell 的第三方资产权利不变，见 ASSETS.md。
